module.exports = {
  singleQuote: true,
  tralingComma: 'all',
  arrowParens: 'avoid',
};
